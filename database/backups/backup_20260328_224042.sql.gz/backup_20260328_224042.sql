--
-- PostgreSQL database dump
--

\restrict JfY9cbXNmJkXDiYfGkEU6ESfd8K8KM6qNfW1K0UI7B2IEq4d5Z24sq5nVqv5YF1

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    user_id character varying,
    action character varying NOT NULL,
    resource character varying,
    resource_id character varying,
    details json,
    ip_address character varying,
    user_agent character varying,
    status character varying,
    error_message character varying,
    created_at timestamp without time zone,
    month integer
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: model_performance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_performance (
    id character varying NOT NULL,
    model_name character varying,
    accuracy double precision,
    "precision" double precision,
    recall double precision,
    f1_score double precision,
    auc_roc double precision,
    period_start timestamp without time zone,
    period_end timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.model_performance OWNER TO postgres;

--
-- Name: player_game_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_game_logs (
    id character varying NOT NULL,
    player_id character varying,
    event_id character varying,
    sport_key character varying,
    date timestamp without time zone,
    opponent character varying,
    home_away character varying,
    stats json,
    team_score integer,
    opponent_score integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.player_game_logs OWNER TO postgres;

--
-- Name: player_prop_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_prop_lines (
    id character varying NOT NULL,
    event_id character varying,
    player_id character varying,
    sport_key character varying,
    stat_type character varying,
    line double precision,
    over_odds integer,
    under_odds integer,
    created_at timestamp without time zone,
    expires_at timestamp without time zone,
    active boolean
);


ALTER TABLE public.player_prop_lines OWNER TO postgres;

--
-- Name: player_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_records (
    id character varying NOT NULL,
    name character varying,
    team_key character varying,
    sport_key character varying,
    "position" character varying,
    external_ids character varying,
    nba_id character varying,
    nfl_id character varying,
    nhl_id character varying,
    mlb_id character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.player_records OWNER TO postgres;

--
-- Name: player_season_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_season_stats (
    id character varying NOT NULL,
    player_id character varying,
    sport_key character varying,
    season integer,
    games_played integer,
    games_started integer,
    minutes_per_game double precision,
    ppg double precision,
    rpg double precision,
    apg double precision,
    spg double precision,
    bpg double precision,
    fg_percent double precision,
    three_pt_percent double precision,
    ft_percent double precision,
    pass_yards_per_game double precision,
    pass_tds integer,
    interceptions integer,
    rush_yards_per_game double precision,
    rush_tds integer,
    receptions_per_game double precision,
    receiving_yards_per_game double precision,
    receiving_tds integer,
    batting_avg double precision,
    home_runs integer,
    rbi integer,
    strikeouts integer,
    era double precision,
    strikeouts_per_9 double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.player_season_stats OWNER TO postgres;

--
-- Name: prediction_accuracy_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prediction_accuracy_stats (
    id character varying NOT NULL,
    user_id character varying,
    sport_key character varying,
    total_predictions integer,
    hits integer,
    misses integer,
    voids integer,
    pending integer,
    win_rate double precision,
    avg_confidence double precision,
    roi double precision,
    last_updated timestamp without time zone,
    last_prediction_id character varying
);


ALTER TABLE public.prediction_accuracy_stats OWNER TO postgres;

--
-- Name: prediction_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prediction_records (
    id character varying NOT NULL,
    user_id character varying,
    sport_key character varying,
    league_id character varying,
    event_id character varying,
    matchup character varying,
    home_team character varying,
    away_team character varying,
    prediction_type character varying,
    prediction character varying,
    player_name character varying,
    player_stat_type character varying,
    line double precision,
    confidence double precision,
    reasoning json,
    model_weights json,
    created_at timestamp without time zone,
    event_start_time timestamp without time zone,
    resolved_at timestamp without time zone,
    outcome character varying,
    actual_result character varying,
    hit_amount double precision
);


ALTER TABLE public.prediction_records OWNER TO postgres;

--
-- Name: predictions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.predictions (
    id character varying NOT NULL,
    sport character varying,
    league character varying,
    matchup character varying,
    prediction character varying,
    confidence double precision,
    odds character varying,
    prediction_type character varying,
    player character varying,
    market_key character varying,
    point double precision,
    event_id character varying,
    sport_key character varying,
    game_time character varying,
    reasoning json,
    model_weights json,
    resolved_at timestamp without time zone,
    result character varying,
    actual_value double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.predictions OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id character varying NOT NULL,
    name character varying,
    tier character varying,
    price double precision,
    predictions_per_day integer,
    confidence_filter double precision,
    features json,
    api_access boolean,
    backtesting boolean,
    support_level character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: training_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_logs (
    id character varying NOT NULL,
    "timestamp" timestamp without time zone,
    duration double precision,
    samples_used integer,
    reason character varying,
    status character varying,
    results json,
    new_weights json,
    error character varying
);


ALTER TABLE public.training_logs OWNER TO postgres;

--
-- Name: user_predictions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_predictions (
    user_id character varying NOT NULL,
    prediction_id character varying NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.user_predictions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying,
    username character varying,
    password_hash character varying,
    subscription_tier character varying,
    subscription_start timestamp without time zone,
    subscription_end timestamp without time zone,
    win_rate double precision,
    total_predictions integer,
    roi double precision,
    profit_loss double precision,
    club_100_unlocked boolean,
    club_100_unlocked_at timestamp without time zone,
    club_100_picks_available integer,
    preferences json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_login timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, action, resource, resource_id, details, ip_address, user_agent, status, error_message, created_at, month) FROM stdin;
4e23080e-f478-4e19-8483-38d9e10d97d2	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:13.39577	3
92412b6d-5e6b-412a-9776-af6361cdcec2	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:15.64018	3
904c358b-3170-41e1-859b-86bf8d3cea82	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:16.322136	3
538bd139-469e-4cec-8612-90e86b049941	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:19.224859	3
1cdbeccd-4e71-4c4e-b7d9-f0a92b67d48c	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:23.134026	3
e0d3366c-96af-499e-88aa-90d21953cd99	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:23.945439	3
b7820bf8-1389-406d-9259-197f476f2dec	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:24.537355	3
7d20399e-7390-40dc-b84f-dd57d840c025	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:24.729322	3
48144bb9-d742-4e13-99a4-e54a04ea5e21	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:24.972821	3
26135e05-45e0-4214-991f-11d7fcc0a6de	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:25.162905	3
a1d0d4b3-4abf-44ec-9475-50077533e55f	unknown	login	user	\N	{}	172.18.0.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	failure	Invalid credentials	2026-03-28 21:01:25.379299	3
\.


--
-- Data for Name: model_performance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_performance (id, model_name, accuracy, "precision", recall, f1_score, auc_roc, period_start, period_end, created_at) FROM stdin;
\.


--
-- Data for Name: player_game_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_game_logs (id, player_id, event_id, sport_key, date, opponent, home_away, stats, team_score, opponent_score, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: player_prop_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_prop_lines (id, event_id, player_id, sport_key, stat_type, line, over_odds, under_odds, created_at, expires_at, active) FROM stdin;
\.


--
-- Data for Name: player_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_records (id, name, team_key, sport_key, "position", external_ids, nba_id, nfl_id, nhl_id, mlb_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: player_season_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_season_stats (id, player_id, sport_key, season, games_played, games_started, minutes_per_game, ppg, rpg, apg, spg, bpg, fg_percent, three_pt_percent, ft_percent, pass_yards_per_game, pass_tds, interceptions, rush_yards_per_game, rush_tds, receptions_per_game, receiving_yards_per_game, receiving_tds, batting_avg, home_runs, rbi, strikeouts, era, strikeouts_per_9, created_at) FROM stdin;
\.


--
-- Data for Name: prediction_accuracy_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prediction_accuracy_stats (id, user_id, sport_key, total_predictions, hits, misses, voids, pending, win_rate, avg_confidence, roi, last_updated, last_prediction_id) FROM stdin;
\.


--
-- Data for Name: prediction_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prediction_records (id, user_id, sport_key, league_id, event_id, matchup, home_team, away_team, prediction_type, prediction, player_name, player_stat_type, line, confidence, reasoning, model_weights, created_at, event_start_time, resolved_at, outcome, actual_result, hit_amount) FROM stdin;
\.


--
-- Data for Name: predictions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.predictions (id, sport, league, matchup, prediction, confidence, odds, prediction_type, player, market_key, point, event_id, sport_key, game_time, reasoning, model_weights, resolved_at, result, actual_value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, tier, price, predictions_per_day, confidence_filter, features, api_access, backtesting, support_level, created_at) FROM stdin;
\.


--
-- Data for Name: training_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_logs (id, "timestamp", duration, samples_used, reason, status, results, new_weights, error) FROM stdin;
\.


--
-- Data for Name: user_predictions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_predictions (user_id, prediction_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, username, password_hash, subscription_tier, subscription_start, subscription_end, win_rate, total_predictions, roi, profit_loss, club_100_unlocked, club_100_unlocked_at, club_100_picks_available, preferences, created_at, updated_at, last_login, is_active) FROM stdin;
afe75250-d1ea-435d-9f9b-679bcd007f45	tester@gmv.com	tester	$2b$12$.0B/7DrS/WYCt664.1GmDesrvOs09WUKpvBwBkbdJ3elBI.dn.lS6	free	2026-03-28 21:01:56.151981	\N	0	0	0	0	f	\N	0	{}	2026-03-28 21:01:56.151985	2026-03-28 21:01:56.151985	\N	t
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: model_performance model_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_performance
    ADD CONSTRAINT model_performance_pkey PRIMARY KEY (id);


--
-- Name: player_game_logs player_game_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_game_logs
    ADD CONSTRAINT player_game_logs_pkey PRIMARY KEY (id);


--
-- Name: player_prop_lines player_prop_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_prop_lines
    ADD CONSTRAINT player_prop_lines_pkey PRIMARY KEY (id);


--
-- Name: player_records player_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_records
    ADD CONSTRAINT player_records_pkey PRIMARY KEY (id);


--
-- Name: player_season_stats player_season_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_season_stats
    ADD CONSTRAINT player_season_stats_pkey PRIMARY KEY (id);


--
-- Name: prediction_accuracy_stats prediction_accuracy_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prediction_accuracy_stats
    ADD CONSTRAINT prediction_accuracy_stats_pkey PRIMARY KEY (id);


--
-- Name: prediction_accuracy_stats prediction_accuracy_stats_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prediction_accuracy_stats
    ADD CONSTRAINT prediction_accuracy_stats_user_id_key UNIQUE (user_id);


--
-- Name: prediction_records prediction_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prediction_records
    ADD CONSTRAINT prediction_records_pkey PRIMARY KEY (id);


--
-- Name: predictions predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.predictions
    ADD CONSTRAINT predictions_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_name_key UNIQUE (name);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_tier_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_tier_key UNIQUE (tier);


--
-- Name: training_logs training_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_logs
    ADD CONSTRAINT training_logs_pkey PRIMARY KEY (id);


--
-- Name: user_predictions user_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_predictions
    ADD CONSTRAINT user_predictions_pkey PRIMARY KEY (user_id, prediction_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_active ON public.player_prop_lines USING btree (active, created_at);


--
-- Name: idx_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event ON public.player_game_logs USING btree (event_id);


--
-- Name: idx_event_sport; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event_sport ON public.player_prop_lines USING btree (event_id, sport_key);


--
-- Name: idx_outcome_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_outcome_date ON public.prediction_records USING btree (outcome, created_at);


--
-- Name: idx_player_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_player_date ON public.player_game_logs USING btree (player_id, date);


--
-- Name: idx_player_season; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_player_season ON public.player_season_stats USING btree (player_id, season);


--
-- Name: idx_player_sport_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_player_sport_id ON public.player_records USING btree (sport_key, nba_id);


--
-- Name: idx_sport_outcome; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sport_outcome ON public.prediction_records USING btree (sport_key, outcome);


--
-- Name: idx_user_sport; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sport ON public.prediction_accuracy_stats USING btree (user_id, sport_key);


--
-- Name: idx_user_sport_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_sport_date ON public.prediction_records USING btree (user_id, sport_key, created_at);


--
-- Name: idx_win_rate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_win_rate ON public.prediction_accuracy_stats USING btree (win_rate);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_resource_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_resource_id ON public.audit_logs USING btree (resource_id);


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_model_performance_model_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_model_performance_model_name ON public.model_performance USING btree (model_name);


--
-- Name: ix_player_game_logs_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_game_logs_date ON public.player_game_logs USING btree (date);


--
-- Name: ix_player_game_logs_event_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_game_logs_event_id ON public.player_game_logs USING btree (event_id);


--
-- Name: ix_player_game_logs_player_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_game_logs_player_id ON public.player_game_logs USING btree (player_id);


--
-- Name: ix_player_prop_lines_event_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_prop_lines_event_id ON public.player_prop_lines USING btree (event_id);


--
-- Name: ix_player_records_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_records_name ON public.player_records USING btree (name);


--
-- Name: ix_player_records_sport_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_records_sport_key ON public.player_records USING btree (sport_key);


--
-- Name: ix_player_season_stats_player_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_season_stats_player_id ON public.player_season_stats USING btree (player_id);


--
-- Name: ix_player_season_stats_season; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_season_stats_season ON public.player_season_stats USING btree (season);


--
-- Name: ix_prediction_records_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_prediction_records_created_at ON public.prediction_records USING btree (created_at);


--
-- Name: ix_prediction_records_event_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_prediction_records_event_id ON public.prediction_records USING btree (event_id);


--
-- Name: ix_prediction_records_sport_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_prediction_records_sport_key ON public.prediction_records USING btree (sport_key);


--
-- Name: ix_prediction_records_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_prediction_records_user_id ON public.prediction_records USING btree (user_id);


--
-- Name: ix_predictions_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_predictions_created_at ON public.predictions USING btree (created_at);


--
-- Name: ix_predictions_league; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_predictions_league ON public.predictions USING btree (league);


--
-- Name: ix_predictions_sport; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_predictions_sport ON public.predictions USING btree (sport);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: player_game_logs player_game_logs_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_game_logs
    ADD CONSTRAINT player_game_logs_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player_records(id);


--
-- Name: player_prop_lines player_prop_lines_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_prop_lines
    ADD CONSTRAINT player_prop_lines_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player_records(id);


--
-- Name: player_season_stats player_season_stats_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_season_stats
    ADD CONSTRAINT player_season_stats_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.player_records(id);


--
-- Name: prediction_accuracy_stats prediction_accuracy_stats_last_prediction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prediction_accuracy_stats
    ADD CONSTRAINT prediction_accuracy_stats_last_prediction_id_fkey FOREIGN KEY (last_prediction_id) REFERENCES public.prediction_records(id);


--
-- Name: prediction_accuracy_stats prediction_accuracy_stats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prediction_accuracy_stats
    ADD CONSTRAINT prediction_accuracy_stats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: prediction_records prediction_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prediction_records
    ADD CONSTRAINT prediction_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_predictions user_predictions_prediction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_predictions
    ADD CONSTRAINT user_predictions_prediction_id_fkey FOREIGN KEY (prediction_id) REFERENCES public.predictions(id);


--
-- Name: user_predictions user_predictions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_predictions
    ADD CONSTRAINT user_predictions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict JfY9cbXNmJkXDiYfGkEU6ESfd8K8KM6qNfW1K0UI7B2IEq4d5Z24sq5nVqv5YF1

