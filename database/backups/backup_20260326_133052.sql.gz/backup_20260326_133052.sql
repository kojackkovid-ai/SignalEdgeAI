--
-- PostgreSQL database dump
--

\restrict qrvBpzZvaRNGY6RxZoqopOkY6RIvhpebNvsFqAYFO8okRf7nGGmA4y5KgU4Ifs2

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict qrvBpzZvaRNGY6RxZoqopOkY6RIvhpebNvsFqAYFO8okRf7nGGmA4y5KgU4Ifs2

